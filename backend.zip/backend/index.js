const express=require('express');
require('./db/config');
const cors=require('cors');
const User=require('./db/User');
const Product=require('./db/Product')
const app=express();
app.use(express.json())
app.use(cors());

//Method 1

// app.post('/register',async(req,res)=>{
//     console.log(req.body);

//    let user= User(req.body);
//     let result=await user.save();
//      result=result.toObject();
//      delete result.password;
//      res.send(result);
//     console.log(result);
// })

//Method 2 from registering

app.post("/register",async(req,res)=>{
    const{name,email,password}=req.body;
    User.findOne({email:email},async(err,user)=>{
        if(user){
            res.send("user already registered");
        }
        else{
                let user=User(req.body)
                let result= await user.save();
                res.send(result);
        }
    })
})
// //Method 2 for Login
 app.post("/login",async(req,res)=>{
     const{email,password}=req.body;
     User.findOne({email:email},async(err,user)=>{
        if(user){
            if(password===user.password){
                res.send( user);
                // res.send("login successful")
                //two send cant be kept togerther
            }
            else{
                res.send("password didnt match");
            }
        }
        else{
            res.send("User not found");
        }
     })
 })

//Method I FOR login

// app.post('/login',async(req,res)=>{
//     console.log(req.body);
//     if(req.body.password&&req.body.email){
//         let user=await User.findOne(req.body).select("-password");
//         if(user){
//             res.send(user);
//         }
//         else{
//             res.send("no data is found in given detail")
//         }
//     }
//     else{
//         res.send("no data is found in not given full detail")
//     }
// })

app.post("/addproduct",async(req,res)=>{
    // res.send(req.body);
    let product=new Product(req.body);
    let result=await product.save();
    res.send(result);
})
app.get("/product",async(req,res)=>{
    let products=await Product.find();
    if(products.length>0){
        res.send(products);
    }
    else{
        res.send({result:"no data found"});
    }
})
// app.delete("/user/:id",async(req,res)=>{
//     let result=await User.deleteOne({_id:req.params.id});
//     res.send(result);
//     // res.send(req.params)
// })
app.delete("/product/:id",async (req,res)=>{
     let result=await Product.deleteOne({_id:req.params.id});
    res.send(result);
   // res.send(req.params); 
})
app.get("/product/:id",async(req,res)=>{
    let result= await Product.findOne({_id:req.params.id});
    if(result){
        res.send(result);
    }
    else{
        res.send({result:"no record is found"})
    }
})
app.put("/product/:id",async(req,res)=>{
    let result=await Product.updateOne(
        {_id:req.params.id},
        {
            $set:req.body
        }
    )
    if(result){
        res.send(result);
    }
    })

app.get('/search/:key',async(req,res)=>{
    let result = await Product.find({
        "$or":[
            {name:{$regex:req.params.key}},
            // {price:{$regex:req.params.key}},
            {company:{$regex:req.params.key}},
            {category:{$regex:req.params.key}}
        ]
    })
    res.send(result);
})
app.listen(5000);























//How To Get Data From MongoDb
// const express=require("express");
// const mongoose=require("mongoose");
// const app=express();
// const connectDb=async()=>{
//     mongoose.connect('mongodb://localhost:27017/e-commerce');
//     const productSchema=new mongoose.Schema({});
//     const product=mongoose.model('product',productSchema);
//     const data=await product.find();
//     console.log(data);
// }
// connectDb();
// app.listen(9000);
















//Method 2(how to remove duplicate product?(Doubt))

// app.post("/addproduct",(req,res)=>{
//     const{name,price,category,company}=req.body;
//     Product.findOne({name:name,price:price,category:category,company:company,userId:userId},
//         async(err,product)=>{
//             if(product){
//                 res.send("product is already present");
//             }
//             else{
//                 let product=Product(req.body);
//                 let result=await product.save();
//                 res.send(result);
//             }
//         })
// })








// //Why This is no working through React
// // for only in one field  email  while it is working through PostMAN api


// if(req.body.name&&req.body.password&&req.body.email)
// {
//     let user =await User.findOne(req.body);
//     if(user){
//         res.send("user already registered")
//     }
   
//     else{
//         user=User(req.body);
//         let result=await user.save();
//         res.send(result);
//         console.log(result)
//     }
// }
// else{
//     res.send("please enter name,emailand apssword");
// }
// })









































// const express=require('express');
// const cors=require("cors");//Import cors from cors module
// require('./db/config');
// const app=express();

// const User=require("./db/User");
// const Product = require('./db/Product');

// const Jwt=require('jsonwebtoken');
// const jwtKey='e-comm';

// app.use(express.json());// Use of MiddleWare


// app.use(cors());//Use Cors As MiddleWare


// // app.post("/register",async(req,res)=>{
// //     let user=new User(req.body);
// //     let result=await user.save();
////Api se jab req ko bhejte h to response m jo database se api m data aati h uska password
////delete kr k dikhane k lite niche vala line use kiye h
// //     result=result.toObject();
// //     delete result.password
// //     res.send(result);
// // })

// app.post("/register",async(req,res)=>{
//     let user=new User(req.body);
//     let result=await user.save();
//     result=result.toObject();
//     delete result.password
//     // res.send(result);
//     Jwt.sign({result},jwtKey,{expiresIn:"2h"},(err,token)=>{
//         if(err){
//             res.send({result:"something went wrong,Please Try After some time "})
//         }
//         res.send({result,auth:token});
// })
// })


// app.post("/login",async(req,res)=>{
//     // console.log(req.body);
//     if(req.body.password &&req.body.email){
//     // let user=await User.findOne(req.body);
////jan Api se data ko database m send krte h to return m postman m data k sath password na dikhaye uske 
////liye use kiye h

//     let user=await User.findOne(req.body).select("-password");
//     if(user){
//             Jwt.sign({user},jwtKey,{expiresIn:"2h"},(err,token)=>{
//                 if(err){
//                     res.send({result:"something went wrong,Please Try After some time "})
//                 }
//                 res.send({user,auth:token});
//             })
//     // console.log(req.body);
//     //  res.send(user);
//     }
//     else{
//         res.send("no user found")
//     }
//     }
//     else{
//         res.send("no user found")
//     }
    
// })


// app.post("/add-product",async(req,res)=>{
//     let product=new Product(req.body);
//     let result=await product.save();
//     //isse product k data ko Postman k through  database m include krte h
//     //aur isme userid dene k liye user ka id copy krte h 
//     res.send(result);

// })
// //data ko send karne se phle hm products ka model banate h
// //Product hamara method h iske andar find method use krenge
// //Product.find() jitne bhi product mongodatabase m data honge vo sab aa jayenge
// //Product.find() promise return krega aur usko handle karne k liye await function use krte h 
// //aur await use krne k liye hm async use krte h
// //ho sakta h database k andar koi product na ho
// app.get('/products',async(req,res)=>{
//     let products= await Product.find();
//     if(products.length>0){
//         res.send(products);
//     }
//     else{
//         res.send({result:"No Products Found"})
//     }
// })
// //Data Get krne k liye delete method hm use krte h
// //product likhne k bad uska id bhi likhte h
// //req.params and req.params.id jis product ko delete karna h uska id hme Postman m de dega
// //ab is id ki help se database se product ko delete karvata hun
// //const result=Product.=>Product module ko use kr rhe h isiliye likha

// // app.delete('/product/:id',(req,res)=>{
// //      res.send("working..")
// //     // res.send(req.params.id);
// // })
// //Since both route has same id but difdferent method so
// // problem won't happen
// app.delete('/product/:id',async(req,res)=>{
//   const result=await Product.deleteOne({_id:req.params.id});
//   res.send(result);
// })
// app.get('/product/:id',async(req,res)=>{
//     let result=await Product.findOne({_id:req.params.id});
//     if(result){
//         res.send(result);
//     }
//     else{
//         res.send({result:"no result found"})
//     }
// })
// app.put('/product/:id',async(req,res)=>{
//     let  result=await Product.updateOne(
//         {_id:req.params.id},
//         {
//             $set:req.body
//         }
//     )
//     res.send(result);
// })
// app.get('/search/:key',async(req,res)=>{
//     let result = await Product.find({
//         "$or":[
//             {name:{$regex:req.params.key}},
//             {price:{$regex:req.params.key}},
//             {company:{$regex:req.params.key}},
//             {category:{$regex:req.params.key}}
//         ]
//     })
//     res.send(result);
// })
// app.listen(9000);
// //object m jab bhi hmlog ek fiewls se jyada field k andar search
// //krte h toh '$or"
